FMQLSSAM ;CG/CD - Caregraf - FMQL Data Query Processor; 05/17/2019  11:30
 ;;1.3;FMQLQP;;May 17th, 2019
 ;
 ;
 ; FMQL Schema Enhancement for Terminologies - sameas relationships
 ;
 ; V1.3 Dummied out as Deprecated. $T checks in callers mean could delete
 ; but just leaving placeholder until V3
 ;
 ; FMQL Query Processor (c) Caregraf 2010-2019 AGPL
 ;
 ; Link (declare sameas) local vocabulary/resources to standard or national 
 ; equivalents. This is part of FMQL's FileMan schema enhancements and 
 ; all vocabs identified in the vocabulary graph should be processed here.
 ;
 ; Get SAMEAS of: LOCAL (no national map where there might be), LOCAL:XX-XX
 ; a local only map, VA:xxxx (usually VUIDs), NLT64 (for Lab only)
 ;
 ; Note: Like other enhancements, the logic could be migrated to FileMan's 
 ; schema. Computed pointers called "sameas" could be added to relevant files.
 ;
 ; IMPORTANT: pass in empty SAMEAS
 ;
RESOLVE(FILENUM,IEN,DEFLABEL,SAMEAS) ;
 Q  ; V1.3
 ;
 ;
 ; TBD: LU LRVER1
 ;
RESVS60(IEN,SAMEAS) ;
 Q
 ;
