FMQLv1 for nodeVistA
