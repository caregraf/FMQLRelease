/* Canned Queries for fmQueryMaker.html */
CANNEDQUERIES = [
	["SELECT 2 LIMIT 10", "List first 10 Patients"],
	["DESCRIBE 2-25", "DESCRIBE Patient 25"],
	["DESCRIBE 9000011 FILTER(.02=9000001-9)", "Problems of Patient 25"],
        ["DESCRIBE 120_8 FILTER(.01=2-25)", "Allergies of Patient 25"],
	["COUNT 120_5 FILTER(.02=2-25)", "How many Vitals for Patient 25?"],
	["DESCRIBE 120_5 FILTER(.02=2-25) LIMIT 10", "First 10 Vitals of Patient 25"],
	["DESCRIBE 120_5 FILTER(.02=2-25&.01>2017-04-01)", "Vitals of Patient 25 from April 2016 on"],
        ["DESCRIBE 100 LIMIT 10", "First 10 Orders"],
	["DESCRIBE 55-25", "Pharmacy Patient of Patient 25"],
        ["DESCRIBE 52 FILTER(2=2-25)", "Prescriptions of Patient 25"],
	["SELECT 8925 FILTER(.02=2-25)", "List documents of Patient 25"],
	["DESCRIBE 8925 FILTER(.02=2-25) LIMIT 2", "First two documents of Patient 25"],
	["COUNT 50", "How many drugs can you dispense?"],
        ["DESCRIBE 50 LIMIT 1", "Describe first drug supported by the system"],
        ["DESCRIBE 50_67 FILTER(4>NEXIUM) LIMIT 10", "Describe all NDCs for Nexium"],
        ["SELECT 9_6 LIMIT 100", "List the first 100 builds"],
        ["COUNT 9_6", "How many builds?"],
        ["DESCRIBE 9_6-1", "Describe the first (Kernel) build (shows CSTOP)"]
];
